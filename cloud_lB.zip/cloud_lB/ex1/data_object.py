class DataObject:
    def __init__(self, name, values):
        self.name = name
        self.values = values
