import socket
import threading

HOST = "localhost"
PORT = 8000


def receive_messages(sock):
    while True:
        try:
            msg = sock.recv(1024).decode()
            if msg:
                print(f"\n[Message] {msg}")
        except:
            print("Disconnected from server.")
            sock.close()
            break


def start_client():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((HOST, PORT))
    print("[CONNECTED] Connected to server.")

    # start receiving thread
    thread = threading.Thread(target=receive_messages, args=(client,))
    thread.daemon = True
    thread.start()

    # main loop to send messages
    while True:
        msg = input("You: ")
        if msg.lower() == "exit":
            break
        client.send(msg.encode())

    client.close()


if __name__ == "__main__":
    start_client()
