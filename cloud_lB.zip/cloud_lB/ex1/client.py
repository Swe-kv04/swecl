import socket
import pickle
from data_object import DataObject

HOST = 'localhost'
PORT = 5001

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((HOST, PORT))

# --- Task 1: Basic Communication ---
# message = "10,20,30,40"
# client_socket.sendall(message.encode())
# data = client_socket.recv(1024).decode()
# print("Sum from server:", data)

# --- Task 2: Object Serialization ---
obj = DataObject("Swetha", [5, 15, 20])
client_socket.sendall(pickle.dumps(obj))
response = client_socket.recv(1024)
result = pickle.loads(response)
print("Response from server:", result)

client_socket.close()
