import Pyro4

# Input the URI provided by the server
uri = input("Enter the server URI: ")

# Connect to the remote object
calculator = Pyro4.Proxy(uri)

# Take user input for numbers
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

# Invoke remote methods
sum_result = calculator.add_numbers(a, b)
product_result = calculator.multiply(a, b)

print("Sum:", sum_result)
print("Product:", product_result)
