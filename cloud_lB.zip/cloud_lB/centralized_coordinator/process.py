import socket
import threading
import json
import time
import sys

COORD_PORT = 7001
my_port = 7100 + int(sys.argv[1])

#lsof -i :7000
# kill -9 12345


def listener():
    s = socket.socket()
    s.bind(('localhost', my_port))
    s.listen(1)
    while True:
        conn, _ = s.accept()
        msg = json.loads(conn.recv(1024).decode())
        if msg['type'] == 'grant':
            print(f"[{my_port}] Entering Critical Section")
            time.sleep(2)
            print(f"[{my_port}] Leaving Critical Section")
            send_message(COORD_PORT, {'type': 'release', 'from_port': my_port})
        conn.close()

def send_message(port, message):
    s = socket.socket()
    try:
        s.connect(('localhost', port))
        s.send(json.dumps(message).encode())
        s.close()
    except:
        pass

threading.Thread(target=listener, daemon=True).start()
time.sleep(2)

while True:
    print(f"[{my_port}] Requesting CS")
    send_message(COORD_PORT, {'type': 'request', 'from_port': my_port})
    time.sleep(5)
