import Pyro4
from calculator import Calculator

# Start a Pyro daemon
daemon = Pyro4.Daemon()  

# Register the Calculator class as a Pyro object
uri = daemon.register(Calculator)

print("Ready. Object URI = ", uri)  # Share this with the client
daemon.requestLoop()  # Start listening for client calls
