import socket
import threading
import time
import sys

PORTS = [5000, 5001, 5002]  # Ring of 3 processes
my_id = int(sys.argv[1])
my_port = PORTS[my_id]
next_port = PORTS[(my_id + 1) % len(PORTS)]

has_token = (my_id == 0)  # Start with process 0

def listen():
    global has_token
    s = socket.socket()
    s.bind(('localhost', my_port))
    s.listen(1)
    while True:
        conn, _ = s.accept()
        token = conn.recv(1024).decode()
        if token == 'TOKEN':
            has_token = True
        conn.close()

def send_token():
    s = socket.socket()
    while True:
        try:
            s.connect(('localhost', next_port))
            s.send(b'TOKEN')
            s.close()
            break
        except:
            time.sleep(1)

threading.Thread(target=listen, daemon=True).start()

while True:
    if has_token:
        print(f"[{my_id}] has the token. Entering Critical Section.")
        time.sleep(2)
        print(f"[{my_id}] leaving Critical Section. Passing token.")
        has_token = False
        send_token()
    time.sleep(1)
