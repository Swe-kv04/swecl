import socket
import threading
import json

PORT = 7001
current = None
queue = []

def handle(conn):
    global current
    data = conn.recv(1024).decode()
    msg = json.loads(data)
    if msg['type'] == 'request':
        if current is None:
            current = msg['from_port']
            send_message(msg['from_port'], {'type': 'grant'})
        else:
            queue.append(msg['from_port'])
    elif msg['type'] == 'release':
        if queue:
            next_port = queue.pop(0)
            current = next_port
            send_message(next_port, {'type': 'grant'})
        else:
            current = None
    conn.close()

def send_message(port, message):
    s = socket.socket()
    try:
        s.connect(('localhost', port))
        s.send(json.dumps(message).encode())
        s.close()
    except:
        pass

s = socket.socket()
s.bind(('localhost', PORT))
s.listen(5)
print("[Coordinator] Running on port", PORT)

while True:
    conn, _ = s.accept()
    threading.Thread(target=handle, args=(conn,), daemon=True).start()
