import socket
import pickle
from data_object import DataObject

HOST = 'localhost'
PORT = 5001

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(1)
print("Server listening on", (HOST, PORT))

conn, addr = server_socket.accept()
print("Connected by", addr)

# Uncomment one of the blocks below to test either task

# --- Task 1: Basic Communication ---
# data = conn.recv(1024).decode()
# numbers = list(map(int, data.split(',')))
# total = sum(numbers)
# conn.sendall(str(total).encode())

# --- Task 2: Object Serialization ---
data = conn.recv(1024)
obj = pickle.loads(data)
if isinstance(obj, DataObject):
    total = sum(obj.values)
    response = f"Hello {obj.name}, sum = {total}"
    conn.sendall(pickle.dumps(response))

conn.close()
